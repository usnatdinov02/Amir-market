import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/components/language-provider";
import { Eye } from "lucide-react";
import { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onViewDetails?: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart, onViewDetails }: ProductCardProps) {
  const { t } = useLanguage();

  return (
    <Card className="group overflow-hidden hover:shadow-xl hover:shadow-blue-500/10 transition-all duration-300 border-0 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm hover:bg-white dark:hover:bg-gray-800">
      <div className="aspect-square overflow-hidden relative">
        <img 
          src={product.imageUrl || "/placeholder-product.jpg"} 
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>
      <CardContent className="p-5">
        <h3 className="font-bold text-gray-900 dark:text-white mb-2 group-hover:text-primary transition-colors duration-200">
          {product.name}
        </h3>
        <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-2 leading-relaxed">
          {product.description}
        </p>
        <div className="flex justify-between items-center">
          <span className="text-2xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
            ${product.price}
          </span>
          <div className="flex space-x-2">
            {onViewDetails && (
              <Button 
                onClick={() => onViewDetails(product)}
                size="sm"
                variant="outline"
                className="hover:bg-primary/10"
              >
                <Eye className="h-4 w-4" />
              </Button>
            )}
            <Button 
              onClick={() => onAddToCart(product)}
              size="sm"
              className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90 text-white shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105"
            >
              {t("addToCart")}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
