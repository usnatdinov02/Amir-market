import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLanguage } from "@/components/language-provider";
import { useTheme } from "@/components/theme-provider";
import { Product, Order } from "@shared/schema";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Edit, Trash2, Plus, Image } from "lucide-react";
import { ImageGalleryPicker } from "@/components/image-gallery-picker";

const loginSchema = z.object({
  password: z.string().min(1, "Password is required"),
});

const productSchema = z.object({
  name: z.string().min(1, "Product name is required"),
  description: z.string().optional(),
  price: z.string().min(1, "Price is required"),
  imageUrl: z.string().optional(),
});

type LoginFormData = z.infer<typeof loginSchema>;
type ProductFormData = z.infer<typeof productSchema>;

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  isAuthenticated: boolean;
  onLogin: (password: string) => Promise<void>;
  onLogout: () => void;
  products: Product[];
  orders: Order[];
  onAddProduct: (product: Omit<Product, 'id' | 'createdAt'>) => Promise<void>;
  onUpdateProduct: (id: string, product: Partial<Product>) => Promise<void>;
  onDeleteProduct: (id: string) => Promise<void>;
  onUpdateOrderStatus: (id: string, status: string) => Promise<void>;
  loginError?: string;
  attemptsRemaining?: number;
  isLocked?: boolean;
  lockoutTime?: number;
  isLoading?: boolean;
}

export function AdminPanel({
  isOpen,
  onClose,
  isAuthenticated,
  onLogin,
  onLogout,
  products,
  orders,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onUpdateOrderStatus,
  loginError,
  attemptsRemaining,
  isLocked,
  lockoutTime,
  isLoading,
}: AdminPanelProps) {
  const { t, language, setLanguage } = useLanguage();
  const { theme, setTheme } = useTheme();
  const [activeTab, setActiveTab] = useState("products");
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showImageGallery, setShowImageGallery] = useState(false);
  const [currentImageField, setCurrentImageField] = useState("");

  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: { password: "" },
  });

  const productForm = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: "",
      description: "",
      price: "",
      imageUrl: "",
    },
  });

  const handleLogin = async (data: LoginFormData) => {
    await onLogin(data.password);
  };

  const handleAddProduct = async (data: ProductFormData) => {
    await onAddProduct({
      name: data.name,
      description: data.description || "",
      price: data.price,
      imageUrl: data.imageUrl || "",
      status: "active",
    });
    setShowAddProduct(false);
    productForm.reset();
  };

  const handleEditProduct = async (data: ProductFormData) => {
    if (!editingProduct) return;
    
    await onUpdateProduct(editingProduct.id, {
      name: data.name,
      description: data.description || "",
      price: data.price,
      imageUrl: data.imageUrl || "",
    });
    setEditingProduct(null);
    productForm.reset();
  };

  const handleImageSelect = (imageUrl: string) => {
    productForm.setValue("imageUrl", imageUrl);
    setShowImageGallery(false);
  };

  const startEdit = (product: Product) => {
    setEditingProduct(product);
    productForm.reset({
      name: product.name,
      description: product.description || "",
      price: product.price,
      imageUrl: product.imageUrl || "",
    });
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "completed": return "default";
      case "processing": return "secondary";
      case "pending": return "outline";
      case "cancelled": return "destructive";
      default: return "outline";
    }
  };

  if (!isAuthenticated) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-sm">
          <div className="text-center space-y-6">
            <h2 className="text-2xl font-bold">{t("adminAccess")}</h2>
            
            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t("password")}</FormLabel>
                      <FormControl>
                        <Input type="password" {...field} disabled={isLocked} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {loginError && (
                  <div className="text-destructive text-sm">
                    {loginError}
                    {attemptsRemaining !== undefined && ` ${attemptsRemaining}`}
                  </div>
                )}
                
                {isLocked && (
                  <div className="text-destructive text-sm">
                    {t("lockoutMessage")} {lockoutTime} {t("minutes")}.
                  </div>
                )}
                
                <div className="flex gap-3">
                  <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                    {t("cancel")}
                  </Button>
                  <Button 
                    type="submit" 
                    className="flex-1"
                    disabled={isLocked || isLoading}
                  >
                    {isLoading ? "Logging in..." : t("login")}
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">{t("adminDashboard")}</h2>
          <Button variant="outline" onClick={onLogout}>
            {t("logout")}
          </Button>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="products">{t("productManagement")}</TabsTrigger>
            <TabsTrigger value="orders">{t("orderManagement")}</TabsTrigger>
            <TabsTrigger value="settings">{t("settings")}</TabsTrigger>
          </TabsList>
          
          <TabsContent value="products" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">{t("productManagement")}</h3>
              <Button onClick={() => setShowAddProduct(true)}>
                <Plus className="h-4 w-4 mr-2" />
                {t("addProduct")}
              </Button>
            </div>
            
            {(showAddProduct || editingProduct) && (
              <Card>
                <CardHeader>
                  <CardTitle>
                    {editingProduct ? t("editProduct") : t("addProduct")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...productForm}>
                    <form 
                      onSubmit={productForm.handleSubmit(
                        editingProduct ? handleEditProduct : handleAddProduct
                      )} 
                      className="space-y-4"
                    >
                      <FormField
                        control={productForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t("productName")}</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={productForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t("description")}</FormLabel>
                            <FormControl>
                              <Textarea rows={2} {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={productForm.control}
                        name="price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t("price")} ($)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.01" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={productForm.control}
                        name="imageUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t("productImage")}</FormLabel>
                            <FormControl>
                              <div className="space-y-3">
                                <Input 
                                  placeholder="Image URL" 
                                  {...field} 
                                />
                                <Button
                                  type="button"
                                  variant="outline"
                                  onClick={() => {
                                    setCurrentImageField(field.value || "");
                                    setShowImageGallery(true);
                                  }}
                                  className="w-full border-2 border-dashed border-muted hover:border-primary/50 transition-colors"
                                >
                                  <Image className="h-5 w-5 mr-2" />
                                  {t("selectFromGallery")}
                                </Button>
                                {field.value && (
                                  <div className="rounded-lg overflow-hidden border">
                                    <img 
                                      src={field.value} 
                                      alt="Product preview"
                                      className="w-full h-32 object-cover"
                                    />
                                  </div>
                                )}
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex gap-3">
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => {
                            setShowAddProduct(false);
                            setEditingProduct(null);
                            productForm.reset();
                          }}
                          className="flex-1"
                        >
                          {t("cancel")}
                        </Button>
                        <Button type="submit" className="flex-1">
                          {editingProduct ? "Update" : t("addProduct")}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            )}
            
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>{t("price")}</TableHead>
                      <TableHead>{t("status")}</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <img 
                              src={product.imageUrl || "/placeholder-product.jpg"}
                              alt={product.name}
                              className="w-10 h-10 rounded object-cover"
                            />
                            <div>
                              <div className="font-medium">{product.name}</div>
                              <div className="text-sm text-muted-foreground">
                                {product.description}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>${product.price}</TableCell>
                        <TableCell>
                          <Badge variant={product.status === "active" ? "default" : "secondary"}>
                            {product.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => startEdit(product)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => onDeleteProduct(product.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="orders" className="space-y-4">
            <h3 className="text-lg font-semibold">{t("orderManagement")}</h3>
            
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t("orderId")}</TableHead>
                      <TableHead>{t("customer")}</TableHead>
                      <TableHead>{t("total")}</TableHead>
                      <TableHead>{t("status")}</TableHead>
                      <TableHead>{t("date")}</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-mono">
                          #{order.id.slice(-6)}
                        </TableCell>
                        <TableCell>{order.customerName}</TableCell>
                        <TableCell>${order.total}</TableCell>
                        <TableCell>
                          <Badge variant={getStatusBadgeVariant(order.status)}>
                            {t(order.status as any)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {new Date(order.createdAt!).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <Select 
                            value={order.status}
                            onValueChange={(status) => onUpdateOrderStatus(order.id, status)}
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="pending">{t("pending")}</SelectItem>
                              <SelectItem value="processing">{t("processing")}</SelectItem>
                              <SelectItem value="completed">{t("completed")}</SelectItem>
                              <SelectItem value="cancelled">{t("cancelled")}</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="settings" className="space-y-4">
            <h3 className="text-lg font-semibold">{t("settings")}</h3>
            
            <div className="grid gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t("themeSettings")}</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={theme} onValueChange={setTheme}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="light" id="light" />
                      <Label htmlFor="light">{t("lightMode")}</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="dark" id="dark" />
                      <Label htmlFor="dark">{t("darkMode")}</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="system" id="system" />
                      <Label htmlFor="system">{t("systemDefault")}</Label>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>{t("languageSettings")}</CardTitle>
                </CardHeader>
                <CardContent>
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="ru">Русский</SelectItem>
                      <SelectItem value="uz">O'zbek</SelectItem>
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Image Gallery Picker */}
        <ImageGalleryPicker
          isOpen={showImageGallery}
          onClose={() => setShowImageGallery(false)}
          onSelect={handleImageSelect}
          currentImage={currentImageField}
        />
      </DialogContent>
    </Dialog>
  );
}
