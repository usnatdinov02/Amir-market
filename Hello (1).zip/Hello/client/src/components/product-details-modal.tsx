import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Star, ShoppingCart, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Product, ProductReview } from "@shared/schema";

const reviewFormSchema = z.object({
  customerName: z.string().min(1, "Name is required"),
  customerEmail: z.string().email().optional().or(z.literal("")),
  rating: z.number().min(1).max(5),
  comment: z.string().optional(),
});

type ReviewFormData = z.infer<typeof reviewFormSchema>;

interface ProductDetailsModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export function ProductDetailsModal({ product, isOpen, onClose, onAddToCart }: ProductDetailsModalProps) {
  const { toast } = useToast();
  const [showReviewForm, setShowReviewForm] = useState(false);

  const { data: reviews = [] } = useQuery<ProductReview[]>({
    queryKey: ["/api/products", product?.id, "reviews"],
    enabled: !!product?.id && isOpen,
  });

  const reviewForm = useForm<ReviewFormData>({
    resolver: zodResolver(reviewFormSchema),
    defaultValues: {
      customerName: "",
      customerEmail: "",
      rating: 5,
      comment: "",
    },
  });

  const addReviewMutation = useMutation({
    mutationFn: (review: ReviewFormData) => 
      apiRequest("POST", `/api/products/${product?.id}/reviews`, review),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products", product?.id, "reviews"] });
      toast({ title: "Review added successfully!" });
      setShowReviewForm(false);
      reviewForm.reset();
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to add review", 
        description: error.message, 
        variant: "destructive" 
      });
    },
  });

  const handleReviewSubmit = (data: ReviewFormData) => {
    addReviewMutation.mutate(data);
  };

  const renderStarRating = (rating: number, interactive = false, onRatingChange?: (rating: number) => void) => {
    return (
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-5 w-5 ${
              interactive ? "cursor-pointer" : ""
            } ${
              star <= rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
            }`}
            onClick={interactive && onRatingChange ? () => onRatingChange(star) : undefined}
          />
        ))}
        {!interactive && <span className="ml-2 text-sm text-gray-600">({rating})</span>}
      </div>
    );
  };

  const averageRating = reviews.length > 0 
    ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length 
    : 0;

  if (!product) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{product.name}</DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-6 md:grid-cols-2">
          {/* Product Information */}
          <div className="space-y-4">
            {product.imageUrl && (
              <img
                src={product.imageUrl}
                alt={product.name}
                className="w-full h-64 object-cover rounded-lg"
              />
            )}
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-3xl font-bold text-green-600">${product.price}</span>
                <div className="flex items-center space-x-2">
                  {renderStarRating(Math.round(averageRating))}
                  <span className="text-sm text-gray-500">({reviews.length} reviews)</span>
                </div>
              </div>
              
              <p className="text-gray-700 dark:text-gray-300">
                {product.description || "No description available"}
              </p>
              
              <div className="flex space-x-3">
                <Button 
                  onClick={() => onAddToCart(product)}
                  className="flex-1"
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Add to Cart
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setShowReviewForm(true)}
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Write Review
                </Button>
              </div>
            </div>
          </div>

          {/* Reviews Section */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Customer Reviews</h3>
            
            {showReviewForm && (
              <Card className="p-4 border-2 border-primary/20">
                <form onSubmit={reviewForm.handleSubmit(handleReviewSubmit)} className="space-y-4">
                  <div>
                    <Label htmlFor="customerName">Your Name</Label>
                    <Input
                      id="customerName"
                      {...reviewForm.register("customerName")}
                      placeholder="Enter your name"
                    />
                    {reviewForm.formState.errors.customerName && (
                      <p className="text-sm text-red-600 mt-1">
                        {reviewForm.formState.errors.customerName.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="customerEmail">Email (optional)</Label>
                    <Input
                      id="customerEmail"
                      type="email"
                      {...reviewForm.register("customerEmail")}
                      placeholder="Enter your email"
                    />
                  </div>

                  <div>
                    <Label>Rating</Label>
                    <div className="mt-1">
                      {renderStarRating(
                        reviewForm.watch("rating"),
                        true,
                        (rating) => reviewForm.setValue("rating", rating)
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="comment">Comment (optional)</Label>
                    <Textarea
                      id="comment"
                      {...reviewForm.register("comment")}
                      placeholder="Share your thoughts about this product..."
                      rows={3}
                    />
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowReviewForm(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit"
                      disabled={addReviewMutation.isPending}
                    >
                      {addReviewMutation.isPending ? "Submitting..." : "Submit Review"}
                    </Button>
                  </div>
                </form>
              </Card>
            )}

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {reviews.map((review) => (
                <Card key={review.id}>
                  <CardContent className="pt-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <span className="font-semibold">{review.customerName}</span>
                        {review.customerEmail && (
                          <span className="text-sm text-gray-500 ml-2">{review.customerEmail}</span>
                        )}
                      </div>
                      {renderStarRating(review.rating)}
                    </div>
                    {review.comment && (
                      <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                        {review.comment}
                      </p>
                    )}
                    <p className="text-xs text-gray-500">
                      {new Date(review.createdAt!).toLocaleDateString()}
                    </p>
                  </CardContent>
                </Card>
              ))}
              
              {reviews.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <MessageSquare className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>No reviews yet. Be the first to review this product!</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}