import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Image, Upload, X } from "lucide-react";
import { useLanguage } from "@/components/language-provider";

interface ImageGalleryPickerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (imageUrl: string) => void;
  currentImage?: string;
}

// Sample product images for the gallery
const SAMPLE_IMAGES = [
  "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
  "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300", 
  "https://images.unsplash.com/photo-1445282768818-728615cc910a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
  "https://images.unsplash.com/photo-1622206151226-18ca2c9ab4a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
  "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
  "https://images.unsplash.com/photo-1559181567-c3190ca9959b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
  "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
  "https://images.unsplash.com/photo-1493770348161-369560ae357d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
  "https://images.unsplash.com/photo-1603833665858-e61d17a86224?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
  "https://images.unsplash.com/photo-1587049352846-4a222e784d38?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
  "https://images.unsplash.com/photo-1552539618-7eec9b4d1796?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
  "https://images.unsplash.com/photo-1589947262488-85dee72c5ad3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
];

export function ImageGalleryPicker({ isOpen, onClose, onSelect, currentImage }: ImageGalleryPickerProps) {
  const { t } = useLanguage();
  const [customUrl, setCustomUrl] = useState(currentImage || "");
  const [selectedImage, setSelectedImage] = useState(currentImage || "");

  const handleSelect = (imageUrl: string) => {
    setSelectedImage(imageUrl);
    setCustomUrl(imageUrl);
  };

  const handleConfirm = () => {
    onSelect(selectedImage || customUrl);
    onClose();
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // In a real application, you would upload this to a server
      // For now, we'll create a local URL
      const url = URL.createObjectURL(file);
      handleSelect(url);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Image className="h-5 w-5" />
            {t("selectFromGallery")}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* File Upload Section */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium">Upload New Image</h3>
            <div className="flex items-center gap-3">
              <label className="cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <div className="flex items-center gap-2 px-4 py-2 border border-dashed border-muted-foreground rounded-lg hover:bg-muted/50 transition-colors">
                  <Upload className="h-4 w-4" />
                  <span className="text-sm">Choose file</span>
                </div>
              </label>
            </div>
          </div>

          {/* Custom URL Input */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium">Or Enter Image URL</h3>
            <div className="flex gap-2">
              <Input
                value={customUrl}
                onChange={(e) => {
                  setCustomUrl(e.target.value);
                  setSelectedImage(e.target.value);
                }}
                placeholder="https://example.com/image.jpg"
                className="flex-1"
              />
              {customUrl && (
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => {
                    setCustomUrl("");
                    setSelectedImage("");
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
          
          {/* Gallery Grid */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium">Select from Gallery</h3>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
              {SAMPLE_IMAGES.map((imageUrl, index) => (
                <Card 
                  key={index}
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    selectedImage === imageUrl ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => handleSelect(imageUrl)}
                >
                  <CardContent className="p-2">
                    <div className="aspect-square overflow-hidden rounded">
                      <img 
                        src={imageUrl} 
                        alt={`Gallery image ${index + 1}`}
                        className="w-full h-full object-cover hover:scale-105 transition-transform"
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Preview Selected Image */}
          {selectedImage && (
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Preview</h3>
              <div className="max-w-sm">
                <img 
                  src={selectedImage} 
                  alt="Selected preview"
                  className="w-full h-32 object-cover rounded-lg border"
                />
              </div>
            </div>
          )}
        </div>

        <div className="flex gap-3 pt-4">
          <Button variant="outline" onClick={onClose} className="flex-1">
            {t("cancel")}
          </Button>
          <Button 
            onClick={handleConfirm} 
            disabled={!selectedImage && !customUrl}
            className="flex-1"
          >
            Select Image
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}