export const translations = {
  en: {
    // Header
    appName: "Amir Market",
    admin: "Admin",
    searchPlaceholder: "Search products...",
    
    // Products
    products: "Products",
    addToCart: "Add to Cart",
    price: "Price",
    description: "Description",
    
    // Cart
    shoppingCart: "Shopping Cart",
    total: "Total",
    quantity: "Quantity",
    proceedToCheckout: "Proceed to Checkout",
    cartEmpty: "Your cart is empty",
    
    // Checkout
    checkout: "Checkout",
    firstName: "First Name",
    lastName: "Last Name",
    phoneNumber: "Phone Number",
    deliveryAddress: "Delivery Address",
    placeOrder: "Place Order",
    cancel: "Cancel",
    
    // Admin
    adminAccess: "Admin Access",
    password: "Password",
    login: "Login",
    logout: "Logout",
    adminDashboard: "Admin Dashboard",
    productManagement: "Product Management",
    orderManagement: "Order Management",
    settings: "Settings",
    addProduct: "Add Product",
    editProduct: "Edit Product",
    deleteProduct: "Delete Product",
    productName: "Product Name",
    productImage: "Product Image",
    selectFromGallery: "Click to select from gallery",
    
    // Orders
    orderId: "Order ID",
    customer: "Customer",
    status: "Status",
    date: "Date",
    pending: "Pending",
    processing: "Processing",
    completed: "Completed",
    cancelled: "Cancelled",
    
    // Settings
    themeSettings: "Theme Settings",
    languageSettings: "Language Settings",
    lightMode: "Light Mode",
    darkMode: "Dark Mode",
    systemDefault: "System Default",
    
    // Messages
    loginError: "Invalid password. Attempts remaining:",
    lockoutMessage: "Too many failed attempts. Please wait",
    minutes: "minutes",
    orderPlaced: "Order placed successfully!",
    productAdded: "Product added successfully!",
    productUpdated: "Product updated successfully!",
    productDeleted: "Product deleted successfully!",
  },
  ru: {
    // Header
    appName: "Amir Market",
    admin: "Админ",
    searchPlaceholder: "Поиск товаров...",
    
    // Products
    products: "Товары",
    addToCart: "В корзину",
    price: "Цена",
    description: "Описание",
    
    // Cart
    shoppingCart: "Корзина",
    total: "Итого",
    quantity: "Количество",
    proceedToCheckout: "Оформить заказ",
    cartEmpty: "Ваша корзина пуста",
    
    // Checkout
    checkout: "Оформление заказа",
    firstName: "Имя",
    lastName: "Фамилия",
    phoneNumber: "Номер телефона",
    deliveryAddress: "Адрес доставки",
    placeOrder: "Разместить заказ",
    cancel: "Отмена",
    
    // Admin
    adminAccess: "Доступ администратора",
    password: "Пароль",
    login: "Войти",
    logout: "Выйти",
    adminDashboard: "Панель администратора",
    productManagement: "Управление товарами",
    orderManagement: "Управление заказами",
    settings: "Настройки",
    addProduct: "Добавить товар",
    editProduct: "Редактировать товар",
    deleteProduct: "Удалить товар",
    productName: "Название товара",
    productImage: "Изображение товара",
    selectFromGallery: "Нажмите для выбора из галереи",
    
    // Orders
    orderId: "ID заказа",
    customer: "Клиент",
    status: "Статус",
    date: "Дата",
    pending: "В ожидании",
    processing: "Обрабатывается",
    completed: "Завершен",
    cancelled: "Отменен",
    
    // Settings
    themeSettings: "Настройки темы",
    languageSettings: "Настройки языка",
    lightMode: "Светлая тема",
    darkMode: "Темная тема",
    systemDefault: "По умолчанию системы",
    
    // Messages
    loginError: "Неверный пароль. Осталось попыток:",
    lockoutMessage: "Слишком много неудачных попыток. Подождите",
    minutes: "минут",
    orderPlaced: "Заказ успешно размещен!",
    productAdded: "Товар успешно добавлен!",
    productUpdated: "Товар успешно обновлен!",
    productDeleted: "Товар успешно удален!",
  },
  uz: {
    // Header
    appName: "Amir Market",
    admin: "Admin",
    searchPlaceholder: "Mahsulotlarni qidirish...",
    
    // Products
    products: "Mahsulotlar",
    addToCart: "Savatga qo'shish",
    price: "Narxi",
    description: "Tavsif",
    
    // Cart
    shoppingCart: "Savat",
    total: "Jami",
    quantity: "Miqdori",
    proceedToCheckout: "Buyurtma berish",
    cartEmpty: "Savatingiz bo'sh",
    
    // Checkout
    checkout: "Buyurtma berish",
    firstName: "Ism",
    lastName: "Familiya",
    phoneNumber: "Telefon raqami",
    deliveryAddress: "Yetkazib berish manzili",
    placeOrder: "Buyurtma berish",
    cancel: "Bekor qilish",
    
    // Admin
    adminAccess: "Admin kirish",
    password: "Parol",
    login: "Kirish",
    logout: "Chiqish",
    adminDashboard: "Admin paneli",
    productManagement: "Mahsulotlarni boshqarish",
    orderManagement: "Buyurtmalarni boshqarish",
    settings: "Sozlamalar",
    addProduct: "Mahsulot qo'shish",
    editProduct: "Mahsulotni tahrirlash",
    deleteProduct: "Mahsulotni o'chirish",
    productName: "Mahsulot nomi",
    productImage: "Mahsulot rasmi",
    selectFromGallery: "Galereyadan tanlash uchun bosing",
    
    // Orders
    orderId: "Buyurtma raqami",
    customer: "Mijoz",
    status: "Holati",
    date: "Sana",
    pending: "Kutilmoqda",
    processing: "Ishlanmoqda",
    completed: "Tugallangan",
    cancelled: "Bekor qilingan",
    
    // Settings
    themeSettings: "Mavzu sozlamalari",
    languageSettings: "Til sozlamalari",
    lightMode: "Yorug' rejim",
    darkMode: "Qorong'u rejim",
    systemDefault: "Tizim bo'yicha",
    
    // Messages
    loginError: "Noto'g'ri parol. Qolgan urinishlar:",
    lockoutMessage: "Juda ko'p muvaffaqiyatsiz urinishlar. Kutib turing",
    minutes: "daqiqa",
    orderPlaced: "Buyurtma muvaffaqiyatli berildi!",
    productAdded: "Mahsulot muvaffaqiyatli qo'shildi!",
    productUpdated: "Mahsulot muvaffaqiyatli yangilandi!",
    productDeleted: "Mahsulot muvaffaqiyatli o'chirildi!",
  },
};

export type Language = keyof typeof translations;
export type TranslationKey = keyof typeof translations.en;

export const getTranslation = (language: Language, key: TranslationKey): string => {
  return translations[language][key] || translations.en[key] || key;
};
