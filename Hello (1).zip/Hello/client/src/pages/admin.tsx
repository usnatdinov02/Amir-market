import { useEffect } from "react";
import { useLocation } from "wouter";
import Home from "./home";

export default function Admin() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Redirect to home page which handles admin functionality
    setLocation("/");
  }, [setLocation]);

  // Render the home component which contains all admin functionality
  return <Home />;
}
