import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Moon, Sun, ShoppingCart, User } from "lucide-react";
import { ProductCard } from "@/components/product-card";
import { ShoppingCart as ShoppingCartComponent, CartItem } from "@/components/shopping-cart";
import { CheckoutModal } from "@/components/checkout-modal";
import { AdminDashboard } from "@/components/admin-dashboard";
import { AuthModal } from "@/components/auth-modal";
import { ProductDetailsModal } from "@/components/product-details-modal";
import { useLanguage } from "@/components/language-provider";
import { useTheme } from "@/components/theme-provider";
import { useToast } from "@/hooks/use-toast";
import { Product, Order } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Home() {
  const { t, language, setLanguage } = useLanguage();
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();

  // State management
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminToken, setAdminToken] = useState<string | null>(
    localStorage.getItem("adminToken")
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [adminLoginError, setAdminLoginError] = useState<string>("");
  const [attemptsRemaining, setAttemptsRemaining] = useState<number | undefined>();
  const [isLocked, setIsLocked] = useState(false);
  const [lockoutTime, setLockoutTime] = useState<number>(0);
  const [logoClickCount, setLogoClickCount] = useState<number>(0);
  const [logoClickTimer, setLogoClickTimer] = useState<NodeJS.Timeout | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(true);
  const [isUserAuthenticated, setIsUserAuthenticated] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // API Queries
  const { data: products = [], refetch: refetchProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: orders = [], refetch: refetchOrders } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
    enabled: isAdminAuthenticated,
  });

  // Mutations
  const createOrderMutation = useMutation({
    mutationFn: (orderData: any) => apiRequest("POST", "/api/orders", orderData),
    onSuccess: () => {
      toast({
        title: "Order placed successfully",
        description: "Your order has been received and is being processed",
      });
      setCartItems([]);
      setIsCheckoutOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
    },
    onError: (error: any) => {
      toast({
        title: "Order failed",
        description: error.message || "Failed to place order",
        variant: "destructive",
      });
    },
  });

  const adminLoginMutation = useMutation({
    mutationFn: (credentials: { password: string }) => 
      apiRequest("POST", "/api/admin/login", credentials),
    onSuccess: (data: any) => {
      setIsAdminAuthenticated(true);
      setAdminToken(data.token);
      localStorage.setItem("adminToken", data.token);
      setAdminLoginError("");
      setAttemptsRemaining(undefined);
      setIsLocked(false);
      setLockoutTime(0);
      toast({
        title: "Admin login successful",
        description: "You are now logged in as administrator",
      });
    },
    onError: (error: any) => {
      setAdminLoginError(error.message);
      if (error.attemptsRemaining !== undefined) {
        setAttemptsRemaining(error.attemptsRemaining);
      }
      if (error.locked) {
        setIsLocked(true);
        setLockoutTime(Date.now() + (5 * 60 * 1000));
      }
    },
  });



  // Effects
  useEffect(() => {
    const savedCart = localStorage.getItem("cartItems");
    if (savedCart) {
      setCartItems(JSON.parse(savedCart));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    if (adminToken) {
      setIsAdminAuthenticated(true);
    }
  }, [adminToken]);

  useEffect(() => {
    let interval: NodeJS.Timeout | undefined;
    if (isLocked && lockoutTime > Date.now()) {
      interval = setInterval(() => {
        if (Date.now() >= lockoutTime) {
          setIsLocked(false);
          setLockoutTime(0);
          clearInterval(interval);
        }
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLocked, lockoutTime]);

  // Handlers
  const addToCart = (product: Product) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id 
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });

    toast({
      title: "Added to cart",
      description: `${product.name} added to cart`,
    });
  };

  const updateCartQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(id);
      return;
    }
    setCartItems(prev =>
      prev.map(item =>
        item.product.id === id ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (id: string) => {
    setCartItems(prev => prev.filter(item => item.product.id !== id));
  };

  const handleCheckout = async (customerData: any) => {
    const orderData = {
      customerName: customerData.name,
      customerPhone: customerData.phone,
      customerEmail: customerData.email,
      items: cartItems.map(item => ({
        productId: item.product.id,
        productName: item.product.name,
        quantity: item.quantity,
        price: item.product.price,
      })),
      total: cartItems.reduce((sum, item) => sum + (parseFloat(item.product.price) * item.quantity), 0),
    };

    await createOrderMutation.mutateAsync(orderData);
  };

  const handleAdminLogin = async (password: string) => {
    await adminLoginMutation.mutateAsync({ password });
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    setAdminToken(null);
    localStorage.removeItem("adminToken");
    setIsAdminOpen(false);
    toast({
      title: "Admin logout successful",
      description: "You have been logged out successfully",
    });
  };



  // Filter products based on search
  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (product.description && product.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  // Handle triple-click admin access
  const handleLogoClick = () => {
    if (logoClickTimer) clearTimeout(logoClickTimer);
    
    const newCount = logoClickCount + 1;
    setLogoClickCount(newCount);
    
    if (newCount === 3) {
      setIsAdminOpen(true);
      setLogoClickCount(0);
    } else {
      const timer = setTimeout(() => setLogoClickCount(0), 1000);
      setLogoClickTimer(timer);
    }
  };

  // Auth handlers
  const handleUserLogin = () => {
    setIsUserAuthenticated(true);
    setIsAuthModalOpen(false);
  };

  const handleAuthAdminLogin = () => {
    setIsAdminAuthenticated(true);
    setIsUserAuthenticated(true);
    setIsAuthModalOpen(false);
    setIsAdminOpen(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-indigo-50/20 dark:from-gray-900 dark:via-blue-900/10 dark:to-indigo-900/5 transition-colors duration-300">
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onUserLogin={handleUserLogin}
        onAdminLogin={handleAuthAdminLogin}
      />

      {isUserAuthenticated && (
        <>
          <header className="bg-white/95 dark:bg-gray-800/95 backdrop-blur-md shadow-lg border-b border-gray-200/50 dark:border-gray-700/50 sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex justify-between items-center h-16">
                <div className="flex-shrink-0">
                  <h1 
                    className="text-2xl font-bold text-gray-900 dark:text-white cursor-pointer select-none hover:text-primary transition-colors duration-200"
                    onClick={handleLogoClick}
                  >
                    {t("appName")}
                  </h1>
                </div>
                
                <div className="flex items-center space-x-4">
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="ru">Русский</SelectItem>
                      <SelectItem value="uz">O'zbek</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                  >
                    <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                    <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                  </Button>
                  
                  <Button variant="ghost" size="icon" onClick={() => setIsCartOpen(true)} className="relative">
                    <ShoppingCart className="h-5 w-5" />
                    {totalItems > 0 && (
                      <span className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-primary text-xs text-white flex items-center justify-center">
                        {totalItems}
                      </span>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </header>

          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
              <div>
                <h2 className="text-4xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-indigo-700 dark:from-white dark:via-blue-200 dark:to-indigo-300 bg-clip-text text-transparent">
                  {t("products")}
                </h2>
                <p className="text-gray-600 dark:text-gray-400 mt-1">Discover our fresh selection</p>
              </div>
              <div className="relative">
                <Input
                  type="text"
                  placeholder={t("searchPlaceholder")}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64 bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm border-gray-200/50 dark:border-gray-700/50 focus:bg-white dark:focus:bg-gray-800 transition-all duration-200"
                />
                <svg className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>

            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={addToCart}
                    onViewDetails={setSelectedProduct}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">
                  {searchQuery ? `No products found for "${searchQuery}"` : "No products available"}
                </p>
              </div>
            )}
          </main>

          <ShoppingCartComponent
            isOpen={isCartOpen}
            onClose={() => setIsCartOpen(false)}
            items={cartItems}
            onUpdateQuantity={updateCartQuantity}
            onRemoveItem={removeFromCart}
            onCheckout={() => {
              setIsCartOpen(false);
              setIsCheckoutOpen(true);
            }}
          />

          <CheckoutModal
            isOpen={isCheckoutOpen}
            onClose={() => setIsCheckoutOpen(false)}
            items={cartItems}
            onSubmit={handleCheckout}
            isLoading={createOrderMutation.isPending}
          />

          <ProductDetailsModal
            product={selectedProduct}
            isOpen={!!selectedProduct}
            onClose={() => setSelectedProduct(null)}
            onAddToCart={addToCart}
          />

          {isAdminAuthenticated && isAdminOpen && (
            <div className="fixed inset-0 bg-white dark:bg-gray-900 z-50 overflow-auto">
              <AdminDashboard onLogout={handleAdminLogout} />
            </div>
          )}
        </>
      )}
    </div>
  );
}