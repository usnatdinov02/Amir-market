import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Moon, Sun, ShoppingCart, User } from "lucide-react";
import { ProductCard } from "@/components/product-card";
import { ShoppingCart as ShoppingCartComponent, CartItem } from "@/components/shopping-cart";
import { CheckoutModal } from "@/components/checkout-modal";
import { AdminPanel } from "@/components/admin-panel";
import { AuthModal } from "@/components/auth-modal";
import { useLanguage } from "@/components/language-provider";
import { useTheme } from "@/components/theme-provider";
import { useToast } from "@/hooks/use-toast";
import { Product, Order } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Home() {
  const { t, language, setLanguage } = useLanguage();
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();

  // State management
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminToken, setAdminToken] = useState<string | null>(
    localStorage.getItem("adminToken")
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [adminLoginError, setAdminLoginError] = useState<string>("");
  const [attemptsRemaining, setAttemptsRemaining] = useState<number | undefined>();
  const [isLocked, setIsLocked] = useState(false);
  const [lockoutTime, setLockoutTime] = useState<number>(0);
  const [logoClickCount, setLogoClickCount] = useState<number>(0);
  const [logoClickTimer, setLogoClickTimer] = useState<NodeJS.Timeout | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(true);
  const [isUserAuthenticated, setIsUserAuthenticated] = useState(false);

  // API Queries
  const { data: products = [], refetch: refetchProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: orders = [], refetch: refetchOrders } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
    enabled: isAdminAuthenticated,
  });

  // Mutations
  const createOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const response = await apiRequest("POST", "/api/orders", orderData);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: t("orderPlaced") });
      setCartItems([]);
      setIsCheckoutOpen(false);
      localStorage.removeItem("cartItems");
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to place order",
        variant: "destructive" 
      });
    },
  });

  const adminLoginMutation = useMutation({
    mutationFn: async (password: string) => {
      const response = await apiRequest("POST", "/api/admin/login", { password });
      return response.json();
    },
    onSuccess: (data) => {
      setAdminToken(data.token);
      setIsAdminAuthenticated(true);
      setAdminLoginError("");
      setAttemptsRemaining(undefined);
      setIsLocked(false);
      localStorage.setItem("adminToken", data.token);
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({ title: "Admin login successful" });
    },
    onError: (error: any) => {
      const errorData = JSON.parse(error.message.split(": ")[1] || "{}");
      if (errorData.isLocked) {
        setIsLocked(true);
        setLockoutTime(errorData.remainingTime || 5);
        setAdminLoginError("");
      } else {
        setAdminLoginError(t("loginError"));
        setAttemptsRemaining(errorData.attemptsRemaining);
      }
    },
  });

  const adminLogoutMutation = useMutation({
    mutationFn: async () => {
      if (adminToken) {
        await apiRequest("POST", "/api/admin/logout", {});
      }
    },
    onSuccess: () => {
      setAdminToken(null);
      setIsAdminAuthenticated(false);
      localStorage.removeItem("adminToken");
      setIsAdminOpen(false);
      toast({ title: "Logged out successfully" });
    },
  });

  const addProductMutation = useMutation({
    mutationFn: async (productData: any) => {
      const response = await apiRequest("POST", "/api/products", productData);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: t("productAdded") });
      refetchProducts();
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to add product",
        variant: "destructive" 
      });
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, ...productData }: any) => {
      const response = await apiRequest("PUT", `/api/products/${id}`, productData);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: t("productUpdated") });
      refetchProducts();
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/products/${id}`);
    },
    onSuccess: () => {
      toast({ title: t("productDeleted") });
      refetchProducts();
    },
  });

  const updateOrderStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const response = await apiRequest("PUT", `/api/orders/${id}/status`, { status });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Order status updated" });
      refetchOrders();
    },
  });

  // Effects
  useEffect(() => {
    const savedCart = localStorage.getItem("cartItems");
    if (savedCart) {
      setCartItems(JSON.parse(savedCart));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    if (adminToken) {
      // Verify token on load
      fetch("/api/admin/verify", {
        headers: { Authorization: `Bearer ${adminToken}` }
      })
      .then(res => res.json())
      .then(data => {
        if (data.valid) {
          setIsAdminAuthenticated(true);
        } else {
          setAdminToken(null);
          localStorage.removeItem("adminToken");
        }
      })
      .catch(() => {
        setAdminToken(null);
        localStorage.removeItem("adminToken");
      });
    }
  }, [adminToken]);

  // Cart functions
  const addToCart = (product: Product) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    toast({ title: `${product.name} added to cart` });
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCartItems(prev =>
      prev.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.product.id !== productId));
  };

  const handleCheckout = (formData: any) => {
    const orderData = {
      customerName: `${formData.firstName} ${formData.lastName}`,
      customerPhone: formData.phone,
      customerAddress: formData.address,
      items: cartItems.map(item => ({
        productId: item.product.id,
        name: item.product.name,
        quantity: item.quantity,
        price: item.product.price,
      })),
      total: cartItems.reduce((sum, item) => 
        sum + (parseFloat(item.product.price) * item.quantity), 0
      ).toFixed(2),
    };

    createOrderMutation.mutate(orderData);
  };

  // Admin functions
  const handleAdminLogin = async (password: string) => {
    adminLoginMutation.mutate(password);
  };

  const handleAdminLogout = () => {
    adminLogoutMutation.mutate();
  };

  const handleAddProduct = async (productData: any) => {
    addProductMutation.mutate(productData);
  };

  const handleUpdateProduct = async (id: string, productData: any) => {
    updateProductMutation.mutate({ id, ...productData });
  };

  const handleDeleteProduct = async (id: string) => {
    if (confirm("Are you sure you want to delete this product?")) {
      deleteProductMutation.mutate(id);
    }
  };

  const handleUpdateOrderStatus = async (id: string, status: string) => {
    updateOrderStatusMutation.mutate({ id, status });
  };

  // Filter products based on search
  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (product.description && product.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  // Handle triple-click admin access
  const handleLogoClick = () => {
    if (logoClickTimer) clearTimeout(logoClickTimer);
    
    const newCount = logoClickCount + 1;
    setLogoClickCount(newCount);
    
    if (newCount === 3) {
      setIsAdminOpen(true);
      setLogoClickCount(0);
    } else {
      const timer = setTimeout(() => setLogoClickCount(0), 1000);
      setLogoClickTimer(timer);
    }
  };

  // Auth handlers
  const handleUserLogin = () => {
    setIsUserAuthenticated(true);
    setIsAuthModalOpen(false);
  };

  const handleAuthAdminLogin = () => {
    setIsAdminAuthenticated(true);
    setIsUserAuthenticated(true);
    setIsAuthModalOpen(false);
    setIsAdminOpen(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-indigo-50/20 dark:from-gray-900 dark:via-blue-900/10 dark:to-indigo-900/5 transition-colors duration-300">
      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onUserLogin={handleUserLogin}
        onAdminLogin={handleAuthAdminLogin}
      />

      {/* Main content - only show when authenticated */}
      {isUserAuthenticated && (
        <>
          {/* Header */}
          <header className="bg-white/95 dark:bg-gray-800/95 backdrop-blur-md shadow-lg border-b border-gray-200/50 dark:border-gray-700/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <h1 
                className="text-2xl font-bold text-gray-900 dark:text-white cursor-pointer select-none hover:text-primary transition-colors duration-200"
                onClick={handleLogoClick}
              >
                {t("appName")}
              </h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Language Selector */}
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="ru">Русский</SelectItem>
                  <SelectItem value="uz">O'zbek</SelectItem>
                </SelectContent>
              </Select>
              
              {/* Dark Mode Toggle */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              >
                <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              </Button>
              
              {/* Shopping Cart */}
              <Button variant="ghost" size="icon" onClick={() => setIsCartOpen(true)} className="relative">
                <ShoppingCart className="h-6 w-6" />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </Button>
              
              {/* Hidden Admin Access - Triple click on logo to access */}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h2 className="text-4xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-indigo-700 dark:from-white dark:via-blue-200 dark:to-indigo-300 bg-clip-text text-transparent">
              {t("products")}
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mt-1">Discover our fresh selection</p>
          </div>
          <div className="relative">
            <Input
              type="text"
              placeholder={t("searchPlaceholder")}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-64 bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm border-gray-200/50 dark:border-gray-700/50 focus:bg-white dark:focus:bg-gray-800 transition-all duration-200"
            />
            <svg className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>
        
        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={addToCart}
            />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400">
              {searchQuery ? `No products found for "${searchQuery}"` : "No products available"}
            </p>
          </div>
        )}
      </main>

      {/* Shopping Cart */}
      <ShoppingCartComponent
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={updateCartQuantity}
        onRemoveItem={removeFromCart}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cartItems}
        onSubmit={handleCheckout}
        isLoading={createOrderMutation.isPending}
      />

          {/* Admin Panel */}
          <AdminPanel
            isOpen={isAdminOpen}
            onClose={() => setIsAdminOpen(false)}
            isAuthenticated={isAdminAuthenticated}
            onLogin={handleAdminLogin}
            onLogout={handleAdminLogout}
            products={products}
            orders={orders}
            onAddProduct={handleAddProduct}
            onUpdateProduct={handleUpdateProduct}
            onDeleteProduct={handleDeleteProduct}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            loginError={adminLoginError}
            attemptsRemaining={attemptsRemaining}
            isLocked={isLocked}
            lockoutTime={lockoutTime}
            isLoading={adminLoginMutation.isPending}
          />
        </>
      ) : null}
    </div>
  );
}
