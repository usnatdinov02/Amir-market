# Amir Market - E-commerce Platform

## Overview

Amir Market is a full-stack e-commerce platform built with React and Express.js. The application provides a modern online shopping experience with features for product browsing, cart management, order processing, customer reviews/ratings, and comprehensive administrative controls. The platform supports internationalization (English, Russian, and Uzbek), dark/light theme switching, and includes an enhanced admin dashboard with statistics, detailed product management, review system, and order tracking.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Components**: shadcn/ui component library built on top of Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: TanStack Query (React Query) for server state, React Context for global state (theme, language)
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation
- **Internationalization**: Custom i18n implementation supporting English, Russian, and Uzbek

### Backend Architecture
- **Runtime**: Node.js with Express.js web framework
- **Language**: TypeScript with ES modules
- **Database Layer**: Drizzle ORM with PostgreSQL dialect
- **Storage**: Dual storage pattern with in-memory storage for development and PostgreSQL for production
- **Authentication**: Session-based admin authentication with rate limiting and IP-based lockout protection
- **API Design**: RESTful endpoints with JSON responses

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Management**: Type-safe database schemas with automated migrations
- **Session Storage**: PostgreSQL-based admin sessions with expiration
- **Development Mode**: In-memory storage fallback for rapid development

### Authentication and Authorization
- **Admin Authentication**: Password-based login with secure session management
- **Rate Limiting**: IP-based attempt tracking with temporary lockouts
- **Session Management**: Token-based sessions with configurable expiration
- **Security**: CSRF protection and secure headers implementation

### Key Features Implementation
- **Product Management**: Full CRUD operations with image support, status management, and detailed product views
- **Customer Reviews**: 1-5 star rating system with optional comments and customer information
- **Order Processing**: Customer information capture, cart-to-order conversion, and status tracking
- **Shopping Cart**: Client-side cart state with persistent storage
- **Enhanced Admin Dashboard**: Comprehensive statistics, analytics, product management, review moderation, and order tracking
- **Product Details Modal**: Customer-facing product view with reviews and rating capabilities
- **Security**: JWT-based admin authentication with secure environment variable credentials
- **Theme System**: Dynamic dark/light mode switching with system preference detection
- **Responsive Design**: Mobile-first approach with adaptive layouts

## External Dependencies

### Database Services
- **@neondatabase/serverless**: Serverless PostgreSQL driver for database connectivity
- **Drizzle ORM**: Type-safe database queries and schema management
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### UI and Styling
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework for rapid styling
- **Lucide React**: Consistent icon library
- **class-variance-authority**: Type-safe variant API for component styling

### Development and Build Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Type safety and enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay for Replit environment

### Form and Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: TypeScript-first schema validation
- **@hookform/resolvers**: Integration between React Hook Form and Zod

### Date and Utility Libraries
- **date-fns**: Modern date utility library
- **clsx & tailwind-merge**: Conditional className utilities
- **nanoid**: URL-safe unique ID generator

### Development Dependencies
- **tsx**: TypeScript execution for Node.js development
- **@types/***: TypeScript definitions for various packages