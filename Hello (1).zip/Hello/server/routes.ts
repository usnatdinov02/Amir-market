import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProductSchema, insertOrderSchema, adminLoginSchema, insertProductReviewSchema } from "@shared/schema";
import { randomBytes } from "crypto";

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const MAX_LOGIN_ATTEMPTS = 3;
const LOCKOUT_DURATION = 5 * 60 * 1000; // 5 minutes

export async function registerRoutes(app: Express): Promise<Server> {
  // Get client IP helper
  const getClientIP = (req: any): string => {
    return req.ip || req.connection.remoteAddress || req.socket.remoteAddress || 
           (req.connection.socket ? req.connection.socket.remoteAddress : null) || 
           req.headers['x-forwarded-for']?.split(',')[0] || 'unknown';
  };

  // Products routes
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      if (!token || !(await storage.getAdminSession(token))) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      if (!token || !(await storage.getAdminSession(token))) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const validatedData = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(req.params.id, validatedData);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      if (!token || !(await storage.getAdminSession(token))) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const success = await storage.deleteProduct(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Orders routes
  app.get("/api/orders", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      if (!token || !(await storage.getAdminSession(token))) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const orders = await storage.getAllOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const validatedData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(validatedData);
      res.status(201).json(order);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  app.put("/api/orders/:id/status", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      if (!token || !(await storage.getAdminSession(token))) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const { status } = req.body;
      if (!status || typeof status !== "string") {
        return res.status(400).json({ message: "Invalid status" });
      }

      const order = await storage.updateOrderStatus(req.params.id, status);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to update order status" });
    }
  });

  // Admin authentication routes
  app.post("/api/admin/login", async (req, res) => {
    try {
      const validatedData = adminLoginSchema.parse(req.body);
      const { username, password } = validatedData;
      const clientIP = getClientIP(req);

      // Check for existing lockout
      const attempts = await storage.getAdminAttempts(clientIP);
      if (attempts?.lockedUntil && new Date() < new Date(attempts.lockedUntil)) {
        const remainingTime = Math.ceil((new Date(attempts.lockedUntil).getTime() - Date.now()) / 1000 / 60);
        return res.status(429).json({ 
          message: "Too many failed attempts", 
          remainingTime,
          isLocked: true 
        });
      }

      if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
        const currentAttempts = (attempts?.attempts || 0) + 1;
        const lockedUntil = currentAttempts >= MAX_LOGIN_ATTEMPTS 
          ? new Date(Date.now() + LOCKOUT_DURATION) 
          : undefined;

        await storage.updateAdminAttempts(clientIP, currentAttempts, lockedUntil);

        if (lockedUntil) {
          return res.status(429).json({ 
            message: "Too many failed attempts", 
            remainingTime: 5,
            isLocked: true 
          });
        }

        return res.status(401).json({ 
          message: "Invalid password", 
          attemptsRemaining: MAX_LOGIN_ATTEMPTS - currentAttempts 
        });
      }

      // Reset attempts on successful login
      await storage.resetAdminAttempts(clientIP);

      // Create session
      const token = randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
      await storage.createAdminSession(token, expiresAt);

      res.json({ token, expiresAt });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/admin/logout", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      if (token) {
        await storage.deleteAdminSession(token);
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Logout failed" });
    }
  });

  app.get("/api/admin/verify", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      if (!token) {
        return res.status(401).json({ message: "No token provided" });
      }

      const session = await storage.getAdminSession(token);
      if (!session) {
        return res.status(401).json({ message: "Invalid or expired token" });
      }

      res.json({ valid: true, expiresAt: session.expiresAt });
    } catch (error) {
      res.status(500).json({ message: "Verification failed" });
    }
  });

  // Product reviews routes
  app.get("/api/products/:id/reviews", async (req, res) => {
    try {
      const reviews = await storage.getProductReviews(req.params.id);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.post("/api/products/:id/reviews", async (req, res) => {
    try {
      const validatedData = insertProductReviewSchema.parse({
        ...req.body,
        productId: req.params.id,
      });
      const review = await storage.createProductReview(validatedData);
      res.status(201).json(review);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.get("/api/admin/reviews", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      if (!token || !(await storage.getAdminSession(token))) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const reviews = await storage.getAllReviews();
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  // Admin statistics route
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      if (!token || !(await storage.getAdminSession(token))) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const products = await storage.getAllProducts();
      const orders = await storage.getAllOrders();
      const reviews = await storage.getAllReviews();
      
      const totalProducts = products.length;
      const totalOrders = orders.length;
      const totalRevenue = orders.reduce((sum, order) => sum + parseFloat(order.total), 0);
      const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
      const totalReviews = reviews.length;
      const averageRating = reviews.length > 0 
        ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length 
        : 0;

      // Order status breakdown
      const ordersByStatus = orders.reduce((acc: Record<string, number>, order) => {
        acc[order.status] = (acc[order.status] || 0) + 1;
        return acc;
      }, {});

      // Recent orders (last 7 days)
      const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const recentOrders = orders.filter(order => new Date(order.createdAt!) > sevenDaysAgo);

      res.json({
        totalProducts,
        totalOrders,
        totalRevenue: totalRevenue.toFixed(2),
        averageOrderValue: averageOrderValue.toFixed(2),
        totalReviews,
        averageRating: averageRating.toFixed(1),
        ordersByStatus,
        recentOrdersCount: recentOrders.length,
        recentRevenue: recentOrders.reduce((sum, order) => sum + parseFloat(order.total), 0).toFixed(2),
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
