import { type User, type InsertUser, type Product, type InsertProduct, type Order, type InsertOrder, type AdminSession, type AdminAttempt, type ProductReview, type InsertProductReview } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Product methods
  getAllProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;

  // Order methods
  getAllOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order | undefined>;

  // Admin session methods
  createAdminSession(token: string, expiresAt: Date): Promise<AdminSession>;
  getAdminSession(token: string): Promise<AdminSession | undefined>;
  deleteAdminSession(token: string): Promise<boolean>;

  // Admin attempt methods
  getAdminAttempts(ipAddress: string): Promise<AdminAttempt | undefined>;
  updateAdminAttempts(ipAddress: string, attempts: number, lockedUntil?: Date): Promise<AdminAttempt>;
  resetAdminAttempts(ipAddress: string): Promise<void>;

  // Product review methods
  getProductReviews(productId: string): Promise<ProductReview[]>;
  createProductReview(review: InsertProductReview): Promise<ProductReview>;
  getAllReviews(): Promise<ProductReview[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  private orders: Map<string, Order>;
  private adminSessions: Map<string, AdminSession>;
  private adminAttempts: Map<string, AdminAttempt>;
  private productReviews: Map<string, ProductReview>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.orders = new Map();
    this.adminSessions = new Map();
    this.adminAttempts = new Map();
    this.productReviews = new Map();

    // Initialize with some sample products
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const sampleProducts: Product[] = [
      {
        id: randomUUID(),
        name: "Fresh Apples",
        description: "Premium quality red apples",
        price: "4.99",
        imageUrl: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        status: "active",
        createdAt: new Date(),
      },
      {
        id: randomUUID(),
        name: "Bananas",
        description: "Sweet and ripe bananas",
        price: "2.99",
        imageUrl: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        status: "active",
        createdAt: new Date(),
      },
      {
        id: randomUUID(),
        name: "Organic Carrots",
        description: "Fresh organic carrots",
        price: "3.49",
        imageUrl: "https://images.unsplash.com/photo-1445282768818-728615cc910a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        status: "active",
        createdAt: new Date(),
      },
      {
        id: randomUUID(),
        name: "Fresh Lettuce",
        description: "Crisp green lettuce leaves",
        price: "1.99",
        imageUrl: "https://images.unsplash.com/photo-1622206151226-18ca2c9ab4a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        status: "active",
        createdAt: new Date(),
      },
    ];

    sampleProducts.forEach(product => {
      this.products.set(product.id, product);
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Product methods
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(p => p.status === "active");
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const newProduct: Product = {
      ...product,
      id,
      description: product.description || null,
      imageUrl: product.imageUrl || null,
      status: product.status || "active",
      createdAt: new Date(),
    };
    this.products.set(id, newProduct);
    return newProduct;
  }

  async updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const existing = this.products.get(id);
    if (!existing) return undefined;

    const updated: Product = { ...existing, ...product };
    this.products.set(id, updated);
    return updated;
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }

  // Order methods
  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const newOrder: Order = {
      ...order,
      id,
      status: order.status || "pending",
      createdAt: new Date(),
    };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async updateOrderStatus(id: string, status: string): Promise<Order | undefined> {
    const existing = this.orders.get(id);
    if (!existing) return undefined;

    const updated: Order = { ...existing, status };
    this.orders.set(id, updated);
    return updated;
  }

  // Admin session methods
  async createAdminSession(token: string, expiresAt: Date): Promise<AdminSession> {
    const id = randomUUID();
    const session: AdminSession = {
      id,
      token,
      expiresAt,
      createdAt: new Date(),
    };
    this.adminSessions.set(token, session);
    return session;
  }

  async getAdminSession(token: string): Promise<AdminSession | undefined> {
    const session = this.adminSessions.get(token);
    if (session && new Date() > new Date(session.expiresAt)) {
      this.adminSessions.delete(token);
      return undefined;
    }
    return session;
  }

  async deleteAdminSession(token: string): Promise<boolean> {
    return this.adminSessions.delete(token);
  }

  // Admin attempt methods
  async getAdminAttempts(ipAddress: string): Promise<AdminAttempt | undefined> {
    return this.adminAttempts.get(ipAddress);
  }

  async updateAdminAttempts(ipAddress: string, attempts: number, lockedUntil?: Date): Promise<AdminAttempt> {
    const id = randomUUID();
    const attempt: AdminAttempt = {
      id,
      ipAddress,
      attempts,
      lockedUntil: lockedUntil || null,
      lastAttempt: new Date(),
    };
    this.adminAttempts.set(ipAddress, attempt);
    return attempt;
  }

  async resetAdminAttempts(ipAddress: string): Promise<void> {
    this.adminAttempts.delete(ipAddress);
  }

  // Product review methods
  async getProductReviews(productId: string): Promise<ProductReview[]> {
    return Array.from(this.productReviews.values()).filter(review => review.productId === productId);
  }

  async createProductReview(review: InsertProductReview): Promise<ProductReview> {
    const id = randomUUID();
    const newReview: ProductReview = {
      ...review,
      id,
      customerEmail: review.customerEmail || null,
      comment: review.comment || null,
      createdAt: new Date(),
    };
    this.productReviews.set(id, newReview);
    return newReview;
  }

  async getAllReviews(): Promise<ProductReview[]> {
    return Array.from(this.productReviews.values());
  }
}

export const storage = new MemStorage();
